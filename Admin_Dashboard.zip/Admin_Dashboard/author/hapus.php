<?php

include "../koneksi.php";

$idauthor=$_GET['idauthor'];

$query=mysqli_query($conn,"DELETE FROM author WHERE id_author='$idauthor'") or die(mysqli_error($conn));

if($query)
{
	echo "<script>alert('Data Author Berhasil dihapus..!!')</script>";
    echo "<script>window.location.href='../main.php?modul=author';</script>";
	
}
else
{
	echo "Gagal Menghapus Data Satuan";
}
?>