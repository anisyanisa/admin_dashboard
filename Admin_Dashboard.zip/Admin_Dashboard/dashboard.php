<div class="page-header">
    <div class="row">

        <div class="col-md-3 col-sm-6">
            <img src="assets/images/avtar/11.png" alt="..." width="85" height="77" align="center">
        </div>
    </div>
    <div class="page-header">
        <h1 align="center">SELAMAT DATANG DI <br><br>Rekapan Artikel TEKNOIF</h1>
    </div>



</div>


</div>