<?php
if ($_GET['modul'] == 'home') {
    include "dashboard.php";
} elseif ($_GET['modul'] == 'author') {
    include "author/author.php";
}